document.addEventListener('DOMContentLoaded', function () {
    var links = document.querySelectorAll('a');

    links.forEach(function (link) {
      link.addEventListener('click', function (event) {
        event.preventDefault();

        links.forEach(function (otherLink) {
          otherLink.classList.remove('selected');
        });

        link.classList.add('selected');
      });
    });
  });

  function toggleDescription() {
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("seeMoreBtn");

    if (moreText.style.display === "none" || moreText.style.display === "") {
      moreText.style.display = "inline";
      btnText.innerHTML = "See Less";
    } else {
      moreText.style.display = "none";
      btnText.innerHTML = "See More..";
    }
  }